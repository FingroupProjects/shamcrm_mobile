class Message {
  final String content;
  final String time;

  Message({required this.content, required this.time});
}
