import 'package:crm_task_manager/api/service/api_service.dart';
import 'package:crm_task_manager/bloc/manager_list/manager_bloc.dart';
import 'package:crm_task_manager/custom_widget/animation.dart';
import 'package:crm_task_manager/custom_widget/custom_app_bar.dart';
import 'package:crm_task_manager/models/deal_model.dart';
import 'package:crm_task_manager/models/lead_multi_model.dart';
import 'package:crm_task_manager/models/manager_model.dart';
import 'package:crm_task_manager/screens/auth/login_screen.dart';
import 'package:crm_task_manager/screens/deal/deal_cache.dart';
import 'package:crm_task_manager/screens/deal/deal_status_delete.dart';
import 'package:crm_task_manager/screens/deal/deal_status_edit.dart';
import 'package:crm_task_manager/screens/deal/tabBar/deal_card.dart';
import 'package:crm_task_manager/screens/deal/tabBar/deal_column.dart';
import 'package:crm_task_manager/screens/deal/tabBar/deal_status_add.dart';
import 'package:crm_task_manager/screens/profile/languages/app_localizations.dart';
import 'package:crm_task_manager/screens/profile/profile_screen.dart';
import 'package:crm_task_manager/utils/TutorialStyleWidget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:crm_task_manager/bloc/deal/deal_bloc.dart';
import 'package:crm_task_manager/bloc/deal/deal_event.dart';
import 'package:crm_task_manager/bloc/deal/deal_state.dart';
import 'package:crm_task_manager/custom_widget/custom_tasks_tabBar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

class DealScreen extends StatefulWidget {
  final int? initialStatusId;

  DealScreen({this.initialStatusId});

  @override
  _DealScreenState createState() => _DealScreenState();
}

class _DealScreenState extends State<DealScreen> with TickerProviderStateMixin {
  late TabController _tabController;
  late ScrollController _scrollController;
  List<Map<String, dynamic>> _tabTitles = [];
  int _currentTabIndex = 0;
  List<GlobalKey> _tabKeys = [];
  bool _isSearching = false;
  bool _isManager = false;

  final TextEditingController _searchController = TextEditingController();
  bool _canReadDealStatus = false;
  bool _canCreateDealStatus = false;
  final ApiService _apiService = ApiService();
  bool navigateToEnd = false;
  bool navigateAfterDelete = false;
  int? _deletedIndex;
  List<int>? _selectedManagerIds;
  int? _selectedManagerId;
  late final DealBloc _dealBloc;

  bool _showCustomTabBar = true;
  String _lastSearchQuery = "";

List<ManagerData> _selectedManagers = [];
  List<LeadData> _selectedLeads = [];
  int? _selectedStatuses;
  DateTime? _fromDate;
  DateTime? _toDate;
  int? _daysWithoutActivity;
  bool? _hasTasks = false;

  List<ManagerData> _initialselectedManagers = [];
  List<LeadData> _initialselectedLeads = [];
  int? _initialSelStatus;
  DateTime? _intialFromDate;
  DateTime? _intialToDate;
  bool? _initialHasTasks;
  int? _initialDaysWithoutActivity;

  final GlobalKey keySearchIcon = GlobalKey();
  final GlobalKey keyMenuIcon = GlobalKey();

  List<TargetFocus> targets = [];
  bool _isTutorialShown = false;
  bool _isDealScreenTutorialCompleted = false;
  Map<String, dynamic>? tutorialProgress;

  @override
  void initState() {
    super.initState();
    context.read<GetAllManagerBloc>().add(GetAllManagerEv());
    _scrollController = ScrollController();
    _scrollController.addListener(_onScroll);

    DealCache.getDealStatuses().then((cachedStatuses) {
      if (cachedStatuses.isNotEmpty) {
        setState(() {
          _tabTitles = cachedStatuses.map((status) => {'id': status['id'], 'title': status['title']}).toList();
          _tabController = TabController(length: _tabTitles.length, vsync: this);
          _tabController.index = _currentTabIndex;

          _tabController.addListener(() {
            setState(() {
              _currentTabIndex = _tabController.index;
            });
            _scrollToActiveTab();
          });
        });
      } else {
        final dealBloc = BlocProvider.of<DealBloc>(context);
        dealBloc.add(FetchDealStatuses());
      }
    });

    DealCache.getDealsForStatus(widget.initialStatusId).then((cachedDeals) {
      if (cachedDeals.isNotEmpty) {
        print('Deals loaded from cache.');
      }
    });
    _checkPermissions();
  }

  void _onScroll() {
  if (_scrollController.position.pixels == _scrollController.position.maxScrollExtent) {
    final dealBloc = BlocProvider.of<DealBloc>(context);
    if (dealBloc.state is DealDataLoaded) {
      final state = dealBloc.state as DealDataLoaded;
      if (!dealBloc.allDealsFetched) {
        final currentStatusId = _tabTitles[_currentTabIndex]['id']; 
        dealBloc.add(FetchMoreDeals(currentStatusId, state.currentPage));
      }
    }
  }
}

  @override
  void dispose() {
    _scrollController.dispose();
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _initTutorialTargets() {
    targets.clear();
    targets.addAll([
      createTarget(
        identify: "DealSearchIcon",
        keyTarget: keySearchIcon,
        title: AppLocalizations.of(context)!.translate('tutorial_task_screen_search_title'),
        description: AppLocalizations.of(context)!.translate('tutorial_deal_screen_search_description'),
        align: ContentAlign.bottom,
        context: context,
        contentPosition: ContentPosition.above,
      ),
      createTarget(
        identify: "DealMenuIcon",
        keyTarget: keyMenuIcon,
        title: AppLocalizations.of(context)!.translate('tutorial_task_screen_menu_title'),
        description: AppLocalizations.of(context)!.translate('tutorial_deal_screen_menu_description'),
        align: ContentAlign.bottom,
        context: context,
        contentPosition: ContentPosition.above,
      ),
    ]);
  }

  Future<void> _checkPermissions() async {
    final canRead = await _apiService.hasPermission('dealStatus.read');
    final canCreate = await _apiService.hasPermission('dealStatus.create');
    setState(() {
      _canReadDealStatus = canRead;
      _canCreateDealStatus = canCreate;
    });

    try {
      final progress = await _apiService.getTutorialProgress();
      if (progress is Map<String, dynamic> && progress['result'] is Map<String, dynamic>) {
        setState(() {
          tutorialProgress = progress['result'];
        });
      } else {
        setState(() {
          tutorialProgress = null;
        });
      }

      SharedPreferences prefs = await SharedPreferences.getInstance();
      bool isTutorialShown = prefs.getBool('isTutorialShownDealSearchIconAppBar') ?? false;
      setState(() {
        _isTutorialShown = isTutorialShown;
      });

      if (tutorialProgress != null &&
          tutorialProgress!['deals']?['index'] == false &&
          !_isTutorialShown &&
          mounted) {
        _initTutorialTargets();
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) {
            showTutorial();
          }
        });
      } else {
        // print('Tutorial not shown for DealScreen. Reasons:');
        // print('tutorialProgress: $tutorialProgress');
        // print('deals/index: ${tutorialProgress?['deals']?['index']}');
        // print('isTutorialShown: $_isTutorialShown');
      }
    } catch (e) {
      print('Error fetching tutorial progress: $e');
    }
  }

  void showTutorial() async {
    if (_isTutorialShown) {
      print('Tutorial already shown for DealScreen, skipping');
      return;
    }

    SharedPreferences prefs = await SharedPreferences.getInstance();
    await Future.delayed(const Duration(milliseconds: 500));

    TutorialCoachMark(
      targets: targets,
      textSkip: AppLocalizations.of(context)!.translate('skip'),
      textStyleSkip: TextStyle(
        color: Colors.white,
        fontFamily: 'Gilroy',
        fontSize: 20,
        fontWeight: FontWeight.w600,
        shadows: [
          Shadow(offset: Offset(-1.5, -1.5), color: Colors.black),
          Shadow(offset: Offset(1.5, -1.5), color: Colors.black),
          Shadow(offset: Offset(1.5, 1.5), color: Colors.black),
          Shadow(offset: Offset(-1.5, 1.5), color: Colors.black),
        ],
      ),
      colorShadow: Color(0xff1E2E52),
      onSkip: () {
        print('Tutorial skipped for DealScreen');
        prefs.setBool('isTutorialShownDealSearchIconAppBar', true);
        setState(() {
          _isTutorialShown = true;
          _isDealScreenTutorialCompleted = true;
        });
        return true;
      },
      onFinish: () {
        print('Tutorial finished for DealScreen');
        prefs.setBool('isTutorialShownDealSearchIconAppBar', true);
        setState(() {
          _isTutorialShown = true;
          _isDealScreenTutorialCompleted = true; 
        });
      },
    ).show(context: context);
  }
  
  Future<void> _searchDeals(String query, int currentStatusId) async {
    final dealBloc = BlocProvider.of<DealBloc>(context);
    await DealCache.clearAllDeals();
    dealBloc.add(FetchDeals(currentStatusId,
        query: query,
        managerIds: _selectedManagers.map((manager) => manager.id).toList(),
        leadIds: _selectedLeads.map((lead) => lead.id).toList(),
        statusIds: _selectedStatuses,
        fromDate: _fromDate,
        toDate: _toDate,
        daysWithoutActivity: _daysWithoutActivity,
        hasTasks: _hasTasks));
  }

  void _resetFilters() {
    setState(() {
      _showCustomTabBar = true;
      _selectedManagers = [];
      _selectedLeads = [];
      _selectedStatuses = null;
      _fromDate = null;
      _hasTasks = false;
      _daysWithoutActivity = null;
      _toDate = null;
      _initialselectedManagers = [];
      _initialselectedLeads = [];
      _initialSelStatus = null;
      _intialFromDate = null;
      _intialToDate = null;
      _lastSearchQuery = '';
      _searchController.clear();
      _initialHasTasks = false;
      _initialDaysWithoutActivity = null;
    });
    final dealBloc = BlocProvider.of<DealBloc>(context);
    dealBloc.add(FetchDealStatuses());
  }

  Future<void> _handleManagerSelected(Map managers) async {
    setState(() {
      _showCustomTabBar = false;
      _selectedManagers = managers['managers'];
      _selectedLeads = managers['leads'];
      _selectedStatuses = managers['statuses'];
      _fromDate = managers['fromDate'];
      _toDate = managers['toDate'];
      _hasTasks = managers['hasTask'];
      _daysWithoutActivity = managers['daysWithoutActivity'];

      _initialHasTasks = managers['hasTask'];
      _initialselectedLeads = managers['leads'];
      _initialDaysWithoutActivity = managers['daysWithoutActivity'];
      _initialselectedManagers = managers['managers'];
      _initialSelStatus = managers['statuses'];
      _intialFromDate = managers['fromDate'];
      _intialToDate = managers['toDate'];
    });

    final currentStatusId = _tabTitles[_currentTabIndex]['id'];
    final dealBloc = BlocProvider.of<DealBloc>(context);
    dealBloc.add(FetchDeals(
      currentStatusId,
      managerIds: _selectedManagers.map((manager) => manager.id).toList(),
      statusIds: _selectedStatuses,
      fromDate: _fromDate,
      toDate: _toDate,
      hasTasks: _hasTasks,
      leadIds: _selectedLeads.map((lead) => lead.id).toList(),
      daysWithoutActivity: _daysWithoutActivity,
      query: _lastSearchQuery.isNotEmpty ? _lastSearchQuery : null,
    ));
  }

  Future _handleStatusSelected(int? selectedStatusId) async {
    setState(() {
      _showCustomTabBar = false;
      _selectedStatuses = selectedStatusId;

      _initialSelStatus = selectedStatusId;
    });

    final currentStatusId = _tabTitles[_currentTabIndex]['id'];
    final taskBloc = BlocProvider.of<DealBloc>(context);
    taskBloc.add(FetchDeals(
      currentStatusId,
      statusIds: _selectedStatuses,
      query: _lastSearchQuery.isNotEmpty ? _lastSearchQuery : null,
    ));
  }

  Future _handleDateSelected(DateTime? fromDate, DateTime? toDate) async {
    setState(() {
      _showCustomTabBar = false;
      _fromDate = fromDate;
      _toDate = toDate;

      _intialFromDate = fromDate;
      _intialToDate = toDate;
    });

    final currentStatusId = _tabTitles[_currentTabIndex]['id'];
    final taskBloc = BlocProvider.of<DealBloc>(context);
    taskBloc.add(FetchDeals(
      currentStatusId,
      fromDate: _fromDate,
      toDate: _toDate,
      query: _lastSearchQuery.isNotEmpty ? _lastSearchQuery : null,
    ));
  }

  Future _handleStatusAndDateSelected(
      int? selectedStatus, DateTime? fromDate, DateTime? toDate) async {
    setState(() {
      _showCustomTabBar = false;
      _selectedStatuses = selectedStatus;
      _fromDate = fromDate;
      _toDate = toDate;

      _initialSelStatus = selectedStatus;
      _intialFromDate = fromDate;
      _intialToDate = toDate;
    });

    final currentStatusId = _tabTitles[_currentTabIndex]['id'];
    final taskBloc = BlocProvider.of<DealBloc>(context);
    taskBloc.add(FetchDeals(
      currentStatusId,
      statusIds: selectedStatus,
      fromDate: _fromDate,
      toDate: _toDate,
      query: _lastSearchQuery.isNotEmpty ? _lastSearchQuery : null,
    ));
  }

  void _onSearch(String query) {
    _lastSearchQuery = query; 
    final currentStatusId = _tabTitles[_currentTabIndex]['id'];
    _searchDeals(query, currentStatusId);
  }

  FocusNode focusNode = FocusNode();
  TextEditingController textEditingController = TextEditingController();
  ValueChanged<String>? onChangedSearchInput;

  bool isClickAvatarIcon = false;

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        forceMaterialTransparency: true,
        title: CustomAppBar(
            SearchIconKey: keySearchIcon,
            menuIconKey: keyMenuIcon,
            title: isClickAvatarIcon
                ? localizations!.translate('appbar_settings')
                : localizations!.translate('appbar_deals'),
            onClickProfileAvatar: () {
              setState(() {
                isClickAvatarIcon = !isClickAvatarIcon;
              });
            },
            onChangedSearchInput: (String value) {
              if (value.isNotEmpty) {
                setState(() {
                  _isSearching = true;
                });
              }
              _onSearch(value);
            },
            onManagersDealSelected: _handleManagerSelected,
            onStatusDealSelected: _handleStatusSelected,
            onDateRangeDealSelected: _handleDateSelected,
            onStatusAndDateRangeDealSelected: _handleStatusAndDateSelected,
            initialManagersDeal: _initialselectedManagers,
            initialLeadsDeal: _initialselectedLeads,
            initialManagerDealStatuses: _initialSelStatus,
            initialManagerDealFromDate: _intialFromDate,
            initialManagerDealToDate: _intialToDate,
            initialManagerDealDaysWithoutActivity: _initialDaysWithoutActivity,
            initialManagerDealHasTasks: _initialHasTasks,
            onDealResetFilters: _resetFilters,
            textEditingController: textEditingController,
            focusNode: focusNode,
            showMenuIcon: _showCustomTabBar,
            showFilterIconOnSelectDeal: !_showCustomTabBar,
            showFilterTaskIcon: false,
            showFilterIcon: false,
            showFilterIconDeal: true,
            showEvent: true,
            showMyTaskIcon: true,
            clearButtonClick: (value) {
              if (value == false) {
                setState(() {
                  _isSearching = false;
                  _searchController.clear();
                  _lastSearchQuery = '';
                });
                if (_searchController.text.isEmpty) {
                  if (_selectedManagers.isEmpty &&
                      _selectedStatuses == null &&
                      _fromDate == null &&
                      _toDate == null &&
                      _selectedLeads.isEmpty &&
                      _hasTasks == false &&
                      _daysWithoutActivity == null) {
                    print("IF SEARCH EMPTY AND NO FILTERS");
                    setState(() {
                      _showCustomTabBar = true;
                    });
                    final taskBloc = BlocProvider.of<DealBloc>(context);
                    taskBloc.add(FetchDealStatuses());
                  } else {
                    print("IF SEARCH EMPTY BUT FILTERS EXIST");
                    final currentStatusId = _tabTitles[_currentTabIndex]['id'];
                    final taskBloc = BlocProvider.of<DealBloc>(context);
                    taskBloc.add(FetchDeals(
                      currentStatusId,
                      managerIds: _selectedManagers.isNotEmpty
                          ? _selectedManagers.map((manager) => manager.id).toList()
                          : null,
                      statusIds: _selectedStatuses,
                      fromDate: _fromDate,
                      toDate: _toDate,
                      daysWithoutActivity: _daysWithoutActivity,
                      hasTasks: _hasTasks,
                      leadIds: _selectedLeads.isNotEmpty
                          ? _selectedLeads.map((lead) => lead.id).toList()
                          : null,
                    ));
                  }
                } else if (_selectedManagerIds != null &&
                    _selectedManagerIds!.isNotEmpty) {
                  print("ELSE IF SEARCH NOT EMPTY");
                  final currentStatusId = _tabTitles[_currentTabIndex]['id'];
                  final taskBloc = BlocProvider.of<DealBloc>(context);
                  taskBloc.add(FetchDeals(
                    currentStatusId,
                    managerIds: _selectedManagerIds,
                    query: _searchController.text.isNotEmpty
                        ? _searchController.text
                        : null,
                  ));
                }
              }
            },
            clearButtonClickFiltr: (value) {}),
      ),
      body: isClickAvatarIcon
          ? ProfileScreen()
          : Column(
              children: [
                const SizedBox(height: 15),
                // Условие для отображения табов с использованием флага
                if (!_isSearching && _selectedManagerId == null && _showCustomTabBar)
                  _buildCustomTabBar(),
                Expanded(
                  child: _isSearching || _selectedManagerId != null
                      ? _buildManagerView()
                      : _buildTabBarView(),
                ),
              ],
            ),
    );
  }

  Widget searchWidget(List<Deal> deals) {
    if (_isSearching) {
      return const Center(
        child: PlayStoreImageLoading(
          size: 80.0,
          duration: Duration(milliseconds: 1000),
        ),
      );
    }
    if (_isManager && deals.isEmpty) {
      return const Center(
        child: PlayStoreImageLoading(
          size: 80.0,
          duration: Duration(milliseconds: 1000),
        ),
      );
    }
    if (_isSearching && deals.isEmpty) {
      return Center(
        child: Text(
          AppLocalizations.of(context)!.translate('nothing_found'),
          style: const TextStyle(
            fontSize: 18,
            fontFamily: 'Gilroy',
            fontWeight: FontWeight.w500,
            color: Color(0xff99A4BA),
          ),
        ),
      );
    }
    else if (_isManager && deals.isEmpty) {
      return Center(
        child: Text(
          'У выбранного менеджера нет сделок',
          style: const TextStyle(
            fontSize: 18,
            fontFamily: 'Gilroy',
            fontWeight: FontWeight.w500,
            color: Color(0xff99A4BA),
          ),
        ),
      );
    }
    if (deals.isNotEmpty) {
      return Flexible(
        child: ListView.builder(
          controller: _scrollController,
          itemCount: deals.length,
          itemBuilder: (context, index) {
            final deal = deals[index];
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: DealCard(
                deal: deal,
                title: deal.dealStatus?.title ?? "",
                statusId: deal.statusId,
                onStatusUpdated: () {},
                onStatusId: (StatusDealId) {},
              ),
            );
          },
        ),
      );
    }
    return Center(
      child: Text(
        AppLocalizations.of(context)!.translate('nothing_deal_for_manager'),
        style: const TextStyle(
          fontSize: 18,
          fontFamily: 'Gilroy',
          fontWeight: FontWeight.w500,
          color: Color(0xff99A4BA),
        ),
      ),
    );
  }

  Widget _buildManagerView() {
    return BlocBuilder<DealBloc, DealState>(
      builder: (context, state) {
        if (state is DealDataLoaded) {
          final List<Deal> deals = state.deals;
          if (deals.isEmpty) {
            return Center(
              child: Text(
                _selectedManagerIds?.isNotEmpty == true
                    ? AppLocalizations.of(context)!.translate('no_manager_in_deal')
                    : AppLocalizations.of(context)!.translate('nothing_found'),
                style: const TextStyle(
                  fontSize: 18,
                  fontFamily: 'Gilroy',
                  fontWeight: FontWeight.w500,
                  color: Color(0xff99A4BA),
                ),
              ),
            );
          }
          return ListView.builder(
            controller: _scrollController,
            itemCount: deals.length,
            itemBuilder: (context, index) {
              final deal = deals[index];
              return Padding(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: DealCard(
                  deal: deal,
                  title: deal.dealStatus?.title ?? "",
                  statusId: deal.statusId,
                  onStatusUpdated: () {},
                  onStatusId: (StatusDealId) {},
                ),
              );
            },
          );
        }
        if (state is DealLoading) {
          return const Center(
            child: PlayStoreImageLoading(
              size: 80.0,
              duration: Duration(milliseconds: 1000),
            ),
          );
        }
        return const SizedBox();
      },
    );
  }

  Widget managerWidget(List<Deal> deals) {
    if (_selectedManagerId != null && deals.isEmpty) {
      return Center(
        child: Text(
          AppLocalizations.of(context)!.translate('no_manager_in_deals'),
          style: const TextStyle(
            fontSize: 18,
            fontFamily: 'Gilroy',
            fontWeight: FontWeight.w500,
            color: Color(0xff99A4BA),
          ),
        ),
      );
    }

    return Flexible(
      child: ListView.builder(
        controller: _scrollController,
        itemCount: deals.length,
        itemBuilder: (context, index) {
          final deal = deals[index];
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: DealCard(
              deal: deal,
              title: deal.dealStatus?.title ?? "",
              statusId: deal.statusId,
              onStatusUpdated: () {},
              onStatusId: (StatusDealId) {},
            ),
          );
        },
      ),
    );
  }

  Widget _buildCustomTabBar() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      controller: _scrollController,
      child: Row(
        children: [
          ...List.generate(_tabTitles.length, (index) {
            if (_tabKeys.length <= index) {
              _tabKeys.add(GlobalKey());
            }
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: _buildTabButton(index),
            );
          }),
          if (_canCreateDealStatus)
            IconButton(
              icon: Image.asset('assets/icons/tabBar/add_black.png',
                  width: 24, height: 24),
              onPressed: _addNewTab,
            ),
        ],
      ),
    );
  }

  void _addNewTab() async {
    final result = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) => CreateStatusDialog(),
    );

    if (result == true) {
      context.read<DealBloc>().add(FetchDealStatuses());

      setState(() {
        navigateToEnd = true;
      });
    }
  }

  void _showStatusOptions(BuildContext context, int index) {
    final RenderBox renderBox =
        _tabKeys[index].currentContext!.findRenderObject() as RenderBox;
    final Offset position = renderBox.localToGlobal(Offset.zero);

    showMenu(
      context: context,
      position: RelativeRect.fromLTRB(
        position.dx,
        position.dy + renderBox.size.height,
        position.dx + renderBox.size.width,
        position.dy + renderBox.size.height * 2,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
      ),
      elevation: 4,
      color: Colors.white,
      items: [
        PopupMenuItem(
          value: 'edit',
          child: ListTile(
            leading: Icon(Icons.edit, color: Color(0xff99A4BA)),
            title: Text(
              'Изменить',
              style: TextStyle(
                fontSize: 16,
                fontFamily: 'Gilroy',
                fontWeight: FontWeight.w500,
                color: Color(0xff1E2E52),
              ),
            ),
          ),
        ),
        PopupMenuItem(
          value: 'delete',
          child: ListTile(
            leading: Icon(Icons.delete, color: Color(0xff99A4BA)),
            title: Text(
              'Удалить',
              style: TextStyle(
                fontSize: 16,
                fontFamily: 'Gilroy',
                fontWeight: FontWeight.w500,
                color: Color(0xff1E2E52),
              ),
            ),
          ),
        ),
      ],
    ).then((value) {
      if (value == 'edit') {
        _showEditDealStatusDialog(index);
      } else if (value == 'delete') {
        _showDeleteDialog(index);
      }
    });
  }

  Widget _buildTabButton(int index) {
    bool isActive = _tabController.index == index;

    return BlocBuilder<DealBloc, DealState>(
      builder: (context, state) {
        int dealCount = 0;

        if (state is DealLoaded) {
          final statusId = _tabTitles[index]['id'];
          final dealStatus = state.dealStatuses.firstWhere(
            (status) => status.id == statusId,
          );
          dealCount = dealStatus.dealsCount;
        }

        return GestureDetector(
          key: _tabKeys[index],
          onTap: () {
            _tabController.animateTo(index);
          },
          onLongPress: () {
            _showStatusOptions(context, index);
          },
          child: Container(
            decoration: TaskStyles.tabButtonDecoration(isActive),
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  _tabTitles[index]['title'],
                  style: TaskStyles.tabTextStyle.copyWith(
                    color: isActive
                        ? TaskStyles.activeColor
                        : TaskStyles.inactiveColor,
                  ),
                ),
                Transform.translate(
                  offset: const Offset(12, 0),
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isActive
                            ? const Color(0xff1E2E52)
                            : const Color(0xff99A4BA),
                        width: 1,
                      ),
                    ),
                    child: Text(
                      dealCount.toString(),
                      style: TextStyle(
                        color:
                            isActive ? Colors.black : const Color(0xff99A4BA),
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        );
      },
    );
  }

// 2. Новый метод для показа диалога редактирования
  void _showEditDealStatusDialog(int index) {
    final dealStatus = _tabTitles[index];

    showDialog(
      context: context,
      builder: (context) => EditDealStatusScreen(
        dealStatusId: dealStatus['id'],
      ),
    ).then((_) =>
        _dealBloc.add(FetchDeals(dealStatus['id'])));
  }

  void _showDeleteDialog(int index) async {
    final dealStatusId = _tabTitles[index]['id'];

    final result = await showDialog(
      context: context,
      builder: (BuildContext context) {
        return DeleteDealStatusDialog(dealStatusId: dealStatusId);
      },
    );

    if (result != null && result) {
      setState(() {
        _deletedIndex = _currentTabIndex;
        navigateAfterDelete = true;

        _tabTitles.removeAt(index);
        _tabKeys.removeAt(index);
        _tabController = TabController(length: _tabTitles.length, vsync: this);

        _currentTabIndex = 0;
        _isSearching = false;
        _searchController.clear();

        context.read<DealBloc>().add(FetchDeals(_currentTabIndex));
      });

    if (_tabTitles.isEmpty) {
        await DealCache.clearAllDeals(); 
        await DealCache.clearCache(); 
      }

      final dealBloc = BlocProvider.of<DealBloc>(context);
      dealBloc.add(FetchDealStatuses());
    }
  }

  Widget _buildTabBarView() {
    return BlocListener<DealBloc, DealState>(
      listener: (context, state) async {
        if (state is DealLoaded) {
          await DealCache.cacheDealStatuses(state.dealStatuses
              .map((status) => {'id': status.id, 'title': status.title})
              .toList());

          setState(() {
            _tabTitles = state.dealStatuses
                .where((status) => _canReadDealStatus)
                .map((status) => {'id': status.id, 'title': status.title})
                .toList();

            _tabKeys = List.generate(_tabTitles.length, (_) => GlobalKey());

            if (_tabTitles.isNotEmpty) {
              _tabController =
                  TabController(length: _tabTitles.length, vsync: this);
              _tabController.addListener(() {
                setState(() {
                  _currentTabIndex = _tabController.index;
                });
                final currentStatusId = _tabTitles[_currentTabIndex]['id'];
                if (_scrollController.hasClients) {
                  _scrollToActiveTab();
                }
              });
              int initialIndex = state.dealStatuses
                  .indexWhere((status) => status.id == widget.initialStatusId);
              if (initialIndex != -1) {
                _tabController.index = initialIndex;
                _currentTabIndex = initialIndex;
              } else {
                _tabController.index = _currentTabIndex;
              }

              if (_scrollController.hasClients) {
                _scrollToActiveTab();
              }
              //Логика для перехода к созданн статусе
              if (navigateToEnd) {
                navigateToEnd = false;
                if (_tabController != null) {
                  _tabController.animateTo(_tabTitles.length - 1);
                }
              }

              //Логика для перехода к после удаления статусе на лево
              if (navigateAfterDelete) {
                navigateAfterDelete = false;
                if (_deletedIndex != null) {
                  if (_deletedIndex == 0 && _tabTitles.length > 1) {
                    _tabController.animateTo(1);
                  } else if (_deletedIndex == _tabTitles.length) {
                    _tabController.animateTo(_tabTitles.length - 1);
                  } else {
                    _tabController.animateTo(_deletedIndex! - 1);
                  }
                }
              }
            }
          });
        } else if (state is DealError) {
          if (state.message.contains(
              AppLocalizations.of(context)!.translate('unauthorized_access'))) {
            ApiService apiService = ApiService();
            await apiService.logout();
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => LoginScreen()),
              (Route<dynamic> route) => false,
            );
          } else if (state.message.contains(
              AppLocalizations.of(context)!.translate('unauthorized_access'))) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  state.message,
                  style: TextStyle(
                    fontFamily: 'Gilroy',
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                  ),
                ),
                behavior: SnackBarBehavior.floating,
                margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                backgroundColor: Colors.red,
                elevation: 3,
                padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                duration: Duration(seconds: 3),
              ),
            );
          }
        }
      },
      child: BlocBuilder<DealBloc, DealState>(
        builder: (context, state) {
          if (state is DealDataLoaded) {
            final List<Deal> deals = state.deals;
            return searchWidget(deals);
          }
          if (state is DealLoading) {
            return const Center(
              child: PlayStoreImageLoading(
                size: 80.0,
                duration: Duration(milliseconds: 1000),
              ),
            );
          } else if (state is DealLoaded) {
            if (_tabTitles.isEmpty) {
              return const Center(child: Text(''));
            }
            return TabBarView(
              controller: _tabController,
              children: List.generate(_tabTitles.length, (index) {
                final statusId = _tabTitles[index]['id'];
                final title = _tabTitles[index]['title'];
                return DealColumn(
                  isDealScreenTutorialCompleted: _isDealScreenTutorialCompleted,
                  statusId: statusId,
                  title: title,
                  managerId: _selectedManagerId, 
                  onStatusId: (newStatusId) {
                    print('Status ID changed: $newStatusId');
                    final index = _tabTitles
                        .indexWhere((status) => status['id'] == newStatusId);

                    BlocProvider.of<DealBloc>(context).add(FetchDealStatuses());

                    if (index != -1) {
                      _tabController.animateTo(index);
                    }
                  },
                );
              }),
            );
          }
          return const SizedBox();
        },
      ),
    );
  }

  void _scrollToActiveTab() {
    final keyContext = _tabKeys[_currentTabIndex].currentContext;
    if (keyContext != null) {
      final box = keyContext.findRenderObject() as RenderBox;
      final position =
          box.localToGlobal(Offset.zero, ancestor: context.findRenderObject());
      final tabWidth = box.size.width;

      if (position.dx < 0 ||
          (position.dx + tabWidth) > MediaQuery.of(context).size.width) {
        double targetOffset = _scrollController.offset +
            position.dx -
            (MediaQuery.of(context).size.width / 2) +
            (tabWidth / 2);

        if (targetOffset != _scrollController.offset) {
          _scrollController.animateTo(
            targetOffset,
            duration: Duration(milliseconds: 100),
            curve: Curves.linear,
          );
        }
      }
    }
  }
}
