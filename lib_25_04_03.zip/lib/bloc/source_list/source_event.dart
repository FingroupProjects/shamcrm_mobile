part of 'source_bloc.dart';

@immutable
sealed class GetAllSourceEvent {}
class GetAllSourceEv extends GetAllSourceEvent {

}
