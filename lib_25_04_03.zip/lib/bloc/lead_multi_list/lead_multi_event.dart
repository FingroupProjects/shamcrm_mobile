part of 'lead_multi_bloc.dart';

@immutable
sealed class GetAllLeadEvent {}
class GetAllLeadEv extends GetAllLeadEvent {

}
