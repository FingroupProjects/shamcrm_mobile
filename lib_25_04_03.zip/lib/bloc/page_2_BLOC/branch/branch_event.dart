// lib/bloc/branch/branch_event.dart
abstract class BranchEvent {}

class FetchBranches extends BranchEvent {}