sealed class GetAllCharacterListEvent {}
class GetAllCharacterListEv extends GetAllCharacterListEvent {}