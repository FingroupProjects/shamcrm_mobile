abstract class DashboardChartEvent {}

class LoadLeadChartData extends DashboardChartEvent {}
