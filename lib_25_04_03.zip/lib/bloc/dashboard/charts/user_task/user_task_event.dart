abstract class TaskCompletionEvent {}

class LoadTaskCompletionData extends TaskCompletionEvent {}
