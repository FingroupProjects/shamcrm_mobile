abstract class DealStatsEvent {}

class LoadDealStatsData extends DealStatsEvent {}
