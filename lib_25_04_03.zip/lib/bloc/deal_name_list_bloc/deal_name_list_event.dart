sealed class GetAllDealNameEvent {}
class GetAllDealNameEv extends GetAllDealNameEvent {}