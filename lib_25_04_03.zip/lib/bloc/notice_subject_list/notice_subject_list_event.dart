sealed class GetAllSubjectEvent {}
class GetAllSubjectEv extends GetAllSubjectEvent {}