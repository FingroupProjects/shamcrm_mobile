import 'package:equatable/equatable.dart';

abstract class Data1CEvent extends Equatable {
  const Data1CEvent();

  @override
  List<Object> get props => [];
}

class FetchData1C extends Data1CEvent {
  const FetchData1C();

  @override
  List<Object> get props => [];
}
