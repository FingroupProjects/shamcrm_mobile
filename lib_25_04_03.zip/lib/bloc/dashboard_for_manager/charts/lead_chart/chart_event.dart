abstract class DashboardChartEventManager {}

class LoadLeadChartDataManager extends DashboardChartEventManager {}
