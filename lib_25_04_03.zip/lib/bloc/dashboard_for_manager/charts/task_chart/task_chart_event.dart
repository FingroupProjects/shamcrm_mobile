// task_chart_event.dart
abstract class DashboardTaskChartEventManager {}

class LoadTaskChartDataManager extends DashboardTaskChartEventManager {}
