// import 'package:equatable/equatable.dart';

// abstract class SourceLeadEvent extends Equatable {
//   const SourceLeadEvent();

//   @override
//   List<Object> get props => [];
// }

// class FetchSourceLead extends SourceLeadEvent {}

abstract class SourceLeadEvent {}

class FetchSourceLead extends SourceLeadEvent {}
