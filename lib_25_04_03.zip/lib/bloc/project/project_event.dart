import 'package:flutter/material.dart';

@immutable
sealed class GetAllProjectEvent {}

class GetAllProjectEv extends GetAllProjectEvent {}
