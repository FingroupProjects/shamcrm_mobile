abstract class DepartmentEvent {}

class FetchDepartment extends DepartmentEvent {}