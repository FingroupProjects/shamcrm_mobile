part of 'get_all_client_bloc.dart';

@immutable
sealed class GetAllClientEvent {}
class GetAllClientEv extends GetAllClientEvent {

}
