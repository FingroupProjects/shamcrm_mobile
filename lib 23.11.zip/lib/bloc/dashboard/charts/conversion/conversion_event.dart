abstract class DashboardConversionEvent {}

class LoadLeadConversionData extends DashboardConversionEvent {}
