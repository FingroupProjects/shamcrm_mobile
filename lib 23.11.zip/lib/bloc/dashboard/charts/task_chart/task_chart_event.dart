// task_chart_event.dart
abstract class DashboardTaskChartEvent {}

class LoadTaskChartData extends DashboardTaskChartEvent {}
