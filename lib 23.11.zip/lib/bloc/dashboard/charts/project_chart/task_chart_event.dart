abstract class ProjectChartEvent {}

class LoadProjectChartData extends ProjectChartEvent {}