class ChatItem {
  final String name;
  final String message;
  final String time;
  final String avatar;
  final String icon;

  ChatItem({
    required this.name,
    required this.message,
    required this.time,
    required this.avatar,
    required this.icon,
  });
}
