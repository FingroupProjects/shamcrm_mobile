import 'package:crm_task_manager/custom_widget/custom_card_tasks_tabBar.dart'; // Импорт кастомного виджета для задач в TabBar
import 'package:crm_task_manager/models/task_model.dart'; // Импорт модели задачи
import 'package:crm_task_manager/screens/task/task_details/task_details_screen.dart'; // Импорт экрана деталей задачи
import 'package:crm_task_manager/screens/task/task_details/task_dropdown_bottom_dialog.dart'; // Импорт виджета выпадающего диалога для выбора статуса задачи
import 'package:flutter/material.dart'; // Импорт Flutter фреймворка
import 'package:intl/intl.dart'; // Импорт для форматирования даты

/// Класс виджета для отображения карточки задачи
class TaskCard extends StatefulWidget {
  final Task task; // Модель данных задачи
  final String name; // Имя текущего статуса задачи
  final int statusId; // ID текущего статуса задачи
  final VoidCallback onStatusUpdated; // Коллбек для обновления статуса задачи
  final String? project; // Название проекта (опционально)
  final int? projectId; // ID проекта (опционально)
  final int? user; // ID ответственного пользователя (опционально)
  final int? userId; // ID пользователя, создавшего задачу (опционально)

  TaskCard({
    required this.task,
    required this.name,
    required this.statusId,
    required this.onStatusUpdated,
    this.project,
    this.projectId,
    this.user,
    this.userId,
  });

  @override
  _TaskCardState createState() => _TaskCardState();
}

class _TaskCardState extends State<TaskCard> {
  late String dropdownValue; // Текущее значение выпадающего списка статусов задачи

  @override
  void initState() {
    super.initState();
    dropdownValue = widget.name;
  }

  /// Форматирование даты в `dd-MM-yyyy`
  String formatDate(String dateString) {
    DateTime dateTime =
        DateTime.parse(dateString); // Преобразование строки в дату
    return DateFormat('dd.MM.yyyy').format(dateTime); // Форматирование даты
  }

  /// Получение цвета фона для приоритета задачи
  Color _getPriorityBackgroundColor(int? priority) {
    switch (priority) {
      case 1:
        return const Color(0xFFE8F5E9); // Цвет для обычного приоритета
      case 3:
        return const Color(0xFFFFEBEE); // Цвет для критического приоритета
      case 2:
        return const Color(0xFFFFF3E0); // Цвет для сложного приоритета
      default:
        return const Color(0xFFE8F5E9); // Цвет по умолчанию
    }
  }

  /// Получение цвета текста для приоритета задачи
  Color _getPriorityTextColor(int? priority) {
    switch (priority) {
      case 1:
        return const Color(0xFF2E7D32); // Цвет для обычного приоритета
      case 3:
        return const Color(0xFFC62828); // Цвет для критического приоритета
      case 2:
        return const Color(0xFFEF6C00); // Цвет для сложного приоритета
      default:
        return const Color(0xFF2E7D32); // Цвет по умолчанию
    }
  }

  /// Получение текстового представления приоритета
  String _getPriorityText(int? priority) {
    switch (priority) {
      case 1:
        return 'Обычный';
      case 3:
        return 'Критический';
      case 2:
        return 'Сложный';
      default:
        return 'Обычный';
    }
  }

  /// Получение инициалов пользователя из имени
  String _getUserInitials(String name) {
    final parts = name.split(' '); // Разделение имени на части
    if (parts.length == 1) {
      return parts[0][0]; // Если только одно слово, берем первую букву
    } else if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'; // Если больше двух, берем первые буквы двух слов
    }
    return '';
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => TaskDetailsScreen(
              taskId:
                  widget.task.id.toString(), // ID задачи для детального экрана
              taskName: widget.task.name ?? 'Без имени', // Название задачи
              startDate: widget.task.startDate, // Дата начала задачи
              endDate: widget.task.endDate, // Дата окончания задачи
              taskStatus: dropdownValue, // Текущий статус задачи
              statusId: widget.statusId, // ID статуса задачи
              priority: widget.task.priority, // Приоритет задачи
              description: widget.task.description, // Описание задачи
              project:
                  widget.task.project?.name ?? widget.project ?? 'Без проекта',
            ),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(12),
        margin: const EdgeInsets.symmetric(vertical: 0, horizontal: 0),
        decoration: TaskCardStyles.taskCardDecoration, // Стиль карточки задачи
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    widget.task.name ?? 'Без имени', // Название задачи
                    style: TaskCardStyles.titleStyle, // Стиль заголовка задачи
                    overflow: TextOverflow
                        .ellipsis, // Обрезка текста, если не помещается
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _getPriorityBackgroundColor(
                        widget.task.priority), // Цвет фона приоритета
                    borderRadius:
                        BorderRadius.circular(16), // Радиус скругления
                  ),
                  child: Text(
                    _getPriorityText(widget.task.priority), // Текст приоритета
                    style: TextStyle(
                      color: _getPriorityTextColor(
                          widget.task.priority), // Цвет текста приоритета
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      fontFamily: 'Gilroy',
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 0), // Отступ в 12 пикселей сверху
            Text(
              widget.task.project?.name ?? 'Без проекта',
              style: const TextStyle(
                fontSize: 16,
                fontFamily: 'Gilroy',
                fontWeight: FontWeight.w500,
                color: Color(0xff99A4BA),
              ),
            ),
            const SizedBox(height: 0),
            Row(
              children: [
                const Text(
                  'Колонка: ', // Надпись "Колонка" для статуса задачи
                  style: TextStyle(
                    fontSize: 16,
                    fontFamily: 'Gilroy',
                    fontWeight: FontWeight.w400,
                    color: Color(0xff99A4BA),
                  ),
                ),
                IntrinsicWidth(
                  child: GestureDetector(
                    onTap: () {
                      DropdownBottomSheet(
                        context,
                        dropdownValue,
                        (String newValue) {
                          setState(() {
                            dropdownValue =
                                newValue; // Обновление статуса задачи
                          });
                          widget
                              .onStatusUpdated(); // Вызов коллбека обновления статуса
                        },
                        widget.task,
                      );
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: const Color(0xff1E2E52),
                          width: 0.2,
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      child: Row(
                        children: [
                          Container(
                            constraints: BoxConstraints(
                                maxWidth: 200), //Размер колонки Выбора Статуса
                            child: Text(
                              dropdownValue,
                              style: const TextStyle(
                                fontSize: 16,
                                fontFamily: 'Gilroy',
                                fontWeight: FontWeight.w500,
                                color: Color(0xff1E2E52),
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Image.asset(
                            'assets/icons/tabBar/dropdown.png',
                            width: 20,
                            height: 20,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                const SizedBox(width: 1),
                if (widget.task.user?.name !=
                    null) // Проверка на наличие имени пользователя
                  Row(
                    children: [
                      Container(
                        width: 30,
                        height: 30,
                        decoration: BoxDecoration(
                          color: const Color.fromARGB(255, 51, 65,
                              98), // Фон иконки инициалов пользователя
                          shape: BoxShape.circle,
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          _getUserInitials(widget.task.user!
                              .name), // Отображение инициалов пользователя
                          style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                Padding(
                  padding: const EdgeInsets.only(
                      left: 12, top: 2), // Отступ слева в 12 пикселей
                  child: Row(
                    children: [
                      Image.asset(
                        'assets/icons/tabBar/date.png', // Иконка даты
                        width: 20,
                        height: 28,
                      ),
                      const SizedBox(width: 2),
                      Text(
                        formatDate(widget.task.endDate ??
                            DateTime.now()
                                .toString()), // Отображение даты окончания задачи
                        style: const TextStyle(
                          fontSize: 16,
                          fontFamily: 'Gilroy',
                          fontWeight: FontWeight.w500,
                          color: Color(0xff99A4BA),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
