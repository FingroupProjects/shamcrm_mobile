import 'package:crm_task_manager/custom_widget/custom_button.dart';
import 'package:crm_task_manager/custom_widget/custom_textfield.dart';
import 'package:crm_task_manager/custom_widget/custom_textfield_deadline.dart'; // Импортируйте новый виджет
import 'package:flutter/material.dart';

class TasksAddScreen extends StatelessWidget {
  final TextEditingController titleController = TextEditingController();
  final TextEditingController deadlineController = TextEditingController(); // Add controller for deadline

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            // Возвращение на предыдущий экран
            Navigator.pop(context);
          },
        ),
        title: Row(
          children: [
            Text(
              'Создания',
              style: TextStyle(
                fontSize: 16,
                fontFamily: 'Gilroy',
                fontWeight: FontWeight.w600,
                color: Color(0xff1E2E52),
              ),
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Название задачи
            CustomTextField(
              controller: titleController,
              hintText: 'Введите название',
              label: 'Название',
            ),
            const SizedBox(height: 16),

            // Колонка
            const Text(
              'В колонке: ToDo',
              style: TextStyle(
                fontSize: 14,
                fontFamily: 'Gilroy',
                fontWeight: FontWeight.w400,
                color: Color(0xff99A4BA),
              ),
            ),
            const SizedBox(height: 16),

            // Дедлайн (заменено на CustomTextFieldDate)
            CustomTextFieldDate(
              controller: deadlineController,
              label: 'Дедлайн',
            ),

            const SizedBox(height: 16),

            // Исполнитель
            const Text(
              'Исполнитель',
              style: TextStyle(
                fontSize: 14,
                fontFamily: 'Gilroy',
                fontWeight: FontWeight.w500,
                color: Color(0xff1E2E52),
              ),
            ),
            const SizedBox(height: 8),
            GestureDetector(
              onTap: () {
                // Добавьте логику для открытия истории действий
              },
              child: Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Color(0xFFF4F7FD),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Image.asset(
                          'assets/images/avatar2.png', // Путь к вашей иконке
                          width: 32, // Укажите нужную ширину иконки
                          height: 32, // Укажите нужную высоту иконки
                        ),
                        SizedBox(width: 8), // Отступ между иконкой и текстом
                        const Text(
                          'Аркадий Поровозов',
                          style: TextStyle(
                            fontSize: 14,
                            fontFamily: 'Gilroy',
                            fontWeight: FontWeight.w500,
                            color: Color(0xfff1E2E52),
                          ),
                        ),
                      ],
                    ),
                    Image.asset(
                      'assets/icons/tabBar/dropdown.png', // Путь к вашему значку
                      width: 16, // Укажите нужную ширину
                      height: 16, // Укажите нужную высоту
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 16),
            Spacer(),

            // Кнопки "Отмена" и "Добавить"
            Row(
              children: [
                Expanded(
                  child: CustomButton(
                    buttonText: 'Отмена',
                    buttonColor: Color(0xfffF4F7FD),
                    textColor: Colors.black,
                    onPressed: () {
                      Navigator.pop(context); // Action for Cancel button
                    },
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: CustomButton(
                    buttonText: 'Добавить',
                    buttonColor: Color(0xff4759FF),
                    textColor: Colors.white,
                    onPressed: () {
                      // Action for Add button
                    },
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
