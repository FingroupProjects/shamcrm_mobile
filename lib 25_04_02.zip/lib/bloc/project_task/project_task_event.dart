import 'package:flutter/material.dart';

@immutable
sealed class GetTaskProjectEvent {}

class GetTaskProjectEv extends GetTaskProjectEvent {}
