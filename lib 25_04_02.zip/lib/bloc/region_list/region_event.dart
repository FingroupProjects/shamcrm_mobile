part of 'region_bloc.dart';

@immutable
sealed class GetAllRegionEvent {}
class GetAllRegionEv extends GetAllRegionEvent {

}
