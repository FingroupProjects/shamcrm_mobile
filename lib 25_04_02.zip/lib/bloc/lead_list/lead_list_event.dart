
import 'package:flutter/material.dart';

@immutable
sealed class GetAllLeadEvent {}
class GetAllLeadEv extends GetAllLeadEvent {}