// Events
abstract class ProcessSpeedEvent {}

class LoadProcessSpeedData extends ProcessSpeedEvent {}
