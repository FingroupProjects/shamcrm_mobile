abstract class DealStatsEventManager {}

class LoadDealStatsManagerData extends DealStatsEventManager {}
