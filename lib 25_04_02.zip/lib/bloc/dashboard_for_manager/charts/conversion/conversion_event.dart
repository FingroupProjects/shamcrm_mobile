abstract class DashboardConversionEventManager {}

class LoadLeadConversionDataManager extends DashboardConversionEventManager {}
