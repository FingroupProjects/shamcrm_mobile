// Events
abstract class ProcessSpeedEventManager {}

class LoadProcessSpeedDataManager extends ProcessSpeedEventManager {}
