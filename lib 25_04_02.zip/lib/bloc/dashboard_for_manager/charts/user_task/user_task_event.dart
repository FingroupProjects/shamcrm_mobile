// Events
abstract class UserEvent {}

class LoadUserData extends UserEvent {}

