abstract class LeadOrderEvent {}

class FetchLeadOrders extends LeadOrderEvent {}