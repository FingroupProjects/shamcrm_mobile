part of 'manager_bloc.dart';

@immutable
sealed class GetAllManagerEvent {}
class GetAllManagerEv extends GetAllManagerEvent {

}
