// // model/user_model.dart
// class UserTaskAdd {
//   final int id;
//   final String name;

//   UserTaskAdd({
//     required this.id,
//     required this.name,
//   });

//   factory UserTaskAdd.fromJson(Map<String, dynamic> json) {
//     return UserTaskAdd(
//       id: json['user_id'],
//       name: json['name'],
//     );
//   }
// }