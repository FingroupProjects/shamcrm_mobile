abstract class DashboardStatsEvent {}

class LoadDashboardStats extends DashboardStatsEvent {}
