
// // Events
// abstract class ChartEventGra {}

// class LoadChartData extends ChartEvent {
//   final String organizationId;
//   final bool thisYear;

//   LoadChartData({required this.organizationId, required this.thisYear});
// }