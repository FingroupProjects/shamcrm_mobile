
// // States
// import 'package:crm_task_manager/models/dashboard_model.dart';

// abstract class ChartState {}

// class ChartInitial extends ChartState {}

// class ChartLoading extends ChartState {}

// class ChartLoaded extends ChartState {
//   final List<ChartData> chartData;

//   ChartLoaded(this.chartData);
// }

// class ChartError extends ChartState {
//   final String message;

//   ChartError(this.message);
// }