// class LeadConversionModel {
//   final List<int> data;

//   LeadConversionModel({required this.data});

//   factory LeadConversionModel.fromJson(Map<String, dynamic> json) {
//     return LeadConversionModel(
//       data: List<int>.from(json['result']['data']),
//     );
//   }
// }