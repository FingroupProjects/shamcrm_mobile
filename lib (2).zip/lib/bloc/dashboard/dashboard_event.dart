
// bloc/dashboard/dashboard_event.dart
abstract class DashboardEvent {}

class LoadDashboardStats extends DashboardEvent {}
class LoadLeadConversionData extends DashboardEvent {}
